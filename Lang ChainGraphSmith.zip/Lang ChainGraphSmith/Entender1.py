from dotenv import load_dotenv #CARGAMOS TODAS LAS VARIABLES DE ENTORNO
from langchain_openai import ChatOpenAI #NOS PERMITE CONECTARNOS A LA API DE OPENAI MEDIANTE LANGCHAIN
from langchain_core.messages import HumanMessage, SystemMessage
load_dotenv()

#CREAMOS EL MODELO EL CUAL USAREMOS
model = ChatOpenAI(model="gpt-4o-mini")

#LE ENTREGAMOS LOS MENSAJES QUE QUEREMOS QUE HAGA EL MODELO
messages = [
    SystemMessage(content="Eres una IA especializada en Futbol Argentino, sabes las copas de cada club y sus hitos historicos, " \
    "debes responder de forma clara y concisa en maximo 4 lineas, además de solo mencionar un equipo."), #CONTEXTO DEL MODELO
    HumanMessage(content="Cual es el club mas grande de argentina y sus mayores logros"), #LO QUE ESCRIBIMOS COMO HUMANOS
]
#EJECUTAMOS EL MODELO
resp = model.invoke(messages) #ENVIAMOS LOS MENSAJES A OPENIA, METODO INVOKE OBTIENE LA RESPUESTA
#LOS SIGUIENTES METODOS SON EQUIVALENTES
###########################################################
#model.invoke("Hello")                                     #
#model.invoke([{"role": "user", "content": "Hello"}])      #
#model.invoke([HumanMessage("Hello")])                     #
###########################################################
print(resp.content) #PRINTEAMOS LA RESPUESTA RECIBIDA
