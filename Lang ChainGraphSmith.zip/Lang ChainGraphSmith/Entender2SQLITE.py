from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import START, StateGraph
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder 
from typing import Sequence
from typing_extensions import Annotated, TypedDict
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, SystemMessage
from langgraph.graph.message import add_messages
from langchain_core.messages.utils import trim_messages
#CREAMOS UNA BASE DE SQLLITE PARA ALMACENAR LA CONVERSACION
import sqlite3
from datetime import datetime, UTC

load_dotenv()
model = ChatOpenAI(model="gpt-4o-mini")

DB_PATH = "chat_history.sqlite3"
def init_db(db_path: str = DB_PATH):
    """Crea tablas si no existen."""
    con = sqlite3.connect(db_path)
    cur = con.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS threads (
            thread_id TEXT PRIMARY KEY,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            thread_id TEXT NOT NULL,
            role TEXT CHECK(role IN ('system','user','assistant')) NOT NULL,
            content TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS summaries (
            thread_id TEXT PRIMARY KEY,
            summary TEXT,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)
    con.commit()
    con.close()
    
def save_message(thread_id: str, role: str, content: str, db_path: str = DB_PATH):
    """Guarda un mensaje (user/assistant/system) en la base."""
    con = sqlite3.connect(db_path)
    cur = con.cursor()
    cur.execute("INSERT OR IGNORE INTO threads(thread_id) VALUES (?)", (thread_id,))
    cur.execute(
        "INSERT INTO messages(thread_id, role, content, created_at) VALUES (?, ?, ?, ?)",
        (thread_id, role, content, datetime.now(UTC).isoformat(timespec="seconds"))
    )
    con.commit()
    con.close()

def save_summary(thread_id: str, summary: str, db_path: str = DB_PATH):
    """Guarda/actualiza el resumen rodante (summary) del thread."""
    con = sqlite3.connect(db_path)
    cur = con.cursor()
    cur.execute("INSERT OR REPLACE INTO summaries(thread_id, summary, updated_at) VALUES (?, ?, ?)",
                (thread_id, summary,datetime.now(UTC).isoformat(timespec="seconds")))
    con.commit()
    con.close()

def load_summary(thread_id: str, db_path: str = DB_PATH) -> str:
    """Carga el resumen guardado (o cadena vacía si no hay)."""
    con = sqlite3.connect(db_path)
    cur = con.cursor()
    cur.execute("SELECT summary FROM summaries WHERE thread_id = ?", (thread_id,))
    row = cur.fetchone()
    con.close()
    return row[0] if row and row[0] else ""

def _to_lc_message(role: str, content: str) -> BaseMessage:
    """Convierte un registro (role, content) a mensaje LangChain."""
    if role == "user":
        return HumanMessage(content=content)
    if role == "assistant":
        return AIMessage(content=content)
    return SystemMessage(content=content)

def load_messages(thread_id: str, db_path: str = DB_PATH) -> Sequence[BaseMessage]:
    """Devuelve la conversación completa de un thread como BaseMessage[]."""
    con = sqlite3.connect(db_path)
    cur = con.cursor()
    cur.execute("""
        SELECT role, content
        FROM messages
        WHERE thread_id = ?
        ORDER BY id ASC
    """, (thread_id,))
    rows = cur.fetchall()
    con.close()
    return [_to_lc_message(role, content) for role, content in rows]

class State(TypedDict):
    messages: Annotated[Sequence[BaseMessage], add_messages]
    language: str                                          
    summary: str                                           

workflow = StateGraph(state_schema=State)
prompt_template = ChatPromptTemplate.from_messages([
    (
        "system",
        "Eres una IA especializada en Pokémon, desde la primera hasta la novena generación. "
        "Responde de forma precisa y directa en {language}.\n\n"
        "Resumen previo de la conversación:\n{summary}"
    ),
    MessagesPlaceholder(variable_name="messages"),
])

trimmer = trim_messages(
    max_tokens=1000,        
    strategy="last",
    token_counter=model,
    include_system=True,
    allow_partial=False,
    start_on="human",
)

def update_summary(old_summary: str, dropped: Sequence[BaseMessage]) -> str:
    summarize_prompt = ChatPromptTemplate.from_messages([
        ("system", "Resume en 3–4 líneas los puntos relevantes para continuar la conversación."),
        ("human", "Resumen previo:\n{old}\n\nFragmentos nuevos:\n{new}"),
    ])
    new_text = "\n".join(m.content for m in dropped if getattr(m, "content", None))
    if not new_text.strip():
        return old_summary
    msg = summarize_prompt.invoke({"old": old_summary, "new": new_text})
    return model.invoke(msg).content.strip()

def call_model(state: State):
    trimmed = trimmer.invoke(state["messages"])
    if len(trimmed) < len(state["messages"]):
        dropped = state["messages"][:len(state["messages"]) - len(trimmed)]
        new_summary = update_summary(state.get("summary", ""), dropped)
    else:
        new_summary = state.get("summary", "")
    prompt = prompt_template.invoke({
        "messages": trimmed,
        "language": state["language"],
        "summary": new_summary,
    })
    response = model.invoke(prompt)
    return {"messages": [response], "summary": new_summary}

workflow.add_node("model", call_model)
workflow.add_edge(START, "model")
memory = MemorySaver()
app = workflow.compile(checkpointer=memory)

THREAD_ID = "abc123"  # CAMBIARLO
config = {"configurable": {"thread_id": THREAD_ID}}

if __name__ == "__main__":
    init_db(DB_PATH)
    persisted_messages = load_messages(THREAD_ID, DB_PATH)
    persisted_summary = load_summary(THREAD_ID, DB_PATH)
    print("¡Bienvenido al chat Pokémon! (Escribe 'salir' para terminar)\n")
    seeded_history = False
    while True:
        user_input = input("Tú: ")
        if user_input.lower() in ["salir", "exit", "quit"]:
            print("👋 ¡Hasta luego!")
            break
        if not user_input.strip():
            continue

        if not seeded_history and persisted_messages:
            payload = {
                "messages": [*persisted_messages, HumanMessage(content=user_input)],
                "language": "es",
                "summary": persisted_summary,
            }
            seeded_history = True
        else:
            payload = {
                "messages": [{"role": "user", "content": user_input}],
                "language": "es",
                "summary": persisted_summary,
            }
        out = app.invoke(payload, config=config)
        ai_response = out["messages"][-1].content.strip()
        new_summary = out.get("summary", persisted_summary)
        print(f"AI: {ai_response}\n")
        save_message(THREAD_ID, "user", user_input, DB_PATH)
        save_message(THREAD_ID, "assistant", ai_response, DB_PATH)
        if new_summary != persisted_summary:
            save_summary(THREAD_ID, new_summary, DB_PATH)
            persisted_summary = new_summary
