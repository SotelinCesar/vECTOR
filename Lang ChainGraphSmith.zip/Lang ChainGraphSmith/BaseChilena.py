from pymongo import MongoClient
from datetime import datetime, timedelta
import json
from math import isnan

uri = "mongodb://cesar:Vector.2025%23@4.203.105.71:27017/close_prices"
client = MongoClient(uri)
db = client["close_prices"]
collection = db["close_prices"]

def prices_consult():
    MINUTES_WINDOW = 1000
    fecha_limite = datetime.now() - timedelta(minutes=MINUTES_WINDOW)
    pipeline = [
        {"$addFields": {
            "time_date": {
                "$dateFromString": {
                    "dateString": "$time",
                    "format": "%Y-%m-%d %H:%M:%S.%L"
                }
            }
        }},
        {"$match": {
        "time_date": {"$gte": fecha_limite},
        "symbol": {"$in": ["LTM", "MALLPLAZA"]}}
        },
        {"$sort": {"symbol": 1, "time_date": -1}},
        {"$group": {"_id": "$symbol", "latest": {"$first": {
            "symbol": "$symbol",
            "protobufData": "$protobufData",
            "time": "$time",
            "time_date": "$time_date"
        }}}}
    ]

    def to_float(x):
        try:
            if x is None:
                return None
            if isinstance(x, str):
                x = x.replace(",", ".").strip()
            v = float(x)
            return v if not isnan(v) else None
        except Exception:
            return None

    def parse_proto(s):
        if isinstance(s, dict):
            return s
        if not isinstance(s, str):
            return {}
        try:
            p = json.loads(s)
            if isinstance(p, str):
                try:
                    p2 = json.loads(p)
                    return p2 if isinstance(p2, dict) else {}
                except Exception:
                    return {}
            return p if isinstance(p, dict) else {}
        except Exception:
            return {}
        

    cursor = collection.aggregate(pipeline)
    rows = []
    for g in cursor:
        symbol = g["_id"]
        proto = parse_proto(g["latest"].get("protobufData"))
        bid = to_float(proto.get("bidPx"))
        ask = to_float(proto.get("askPx"))
        last = to_float(proto.get("last"))
        if last is None:
            last = to_float((proto.get("ohlcv") or {}).get("close"))
        if bid is None:
            bid = to_float(proto.get("referencialPrice"))
        rows.append((symbol, bid, ask, last))

    rows.sort(key=lambda x: x[0])
    print(f"{'Acción':<12} {'Compra(bid)':>12} {'Venta(ask)':>12} {'Valor(last)':>12}")
    for sym, bid, ask, last in rows:
        b = f"{bid:.2f}" if bid is not None else "-"
        a = f"{ask:.2f}" if ask is not None else "-"
        l = f"{last:.2f}" if last is not None else "-"
        print(f"{sym:<12} {b:>12} {a:>12} {l:>12}")


if __name__ == "__main__":
    seleccion = input("1: Obtener valor de acción \n" \
    "2: Obtener rendimiento de acción \n ")
    if seleccion == "1":
        prices_consult()
    elif seleccion == "2":
        print("Por el momento no tengo esta opción")
    print("END")
