import os
from dotenv import load_dotenv
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
import datetime,time
import pandas as pd
import unicodedata
load_dotenv()

LV_URL = "https://mercados.larrainvial.com/www/v2/index.html?mercado=chile"
URL = LV_URL 

def _limpiar_txt(s: str) -> str:
    return " ".join((s or "").replace("\xa0", " ").split()).strip()

def _imprimir_tabla(headers: list[str], rows: list[list[str]], titulo: str):
    print(f"\n=== {titulo} ===")
    if headers:
        print("HEADERS:", " | ".join(headers))
    else:
        print("HEADERS: (sin headers)")
    print(f"FILAS: {len(rows)}")
    for i, r in enumerate(rows):
        print(f"[{i}] " + " | ".join(r))

def _tabla_a_matriz(table_locator):
    headers = []
    try:
        headers = [_limpiar_txt(x) for x in table_locator.locator("thead th, tr th").all_text_contents()]
    except Exception:
        headers = []
    if not headers:
        try:
            first_row = table_locator.locator("tr").first
            headers = [_limpiar_txt(x) for x in first_row.locator("th, td").all_text_contents()]
        except Exception:
            headers = []
    body_rows = table_locator.locator("tbody tr")
    nrows = body_rows.count()
    rows = []
    for i in range(nrows):
        rloc = body_rows.nth(i)
        ctexts = [_limpiar_txt(x) for x in rloc.locator("th, td").all_text_contents()]
        rows.append(ctexts)
    return headers, rows

def dump_full_tables_all_frames():
    from playwright.sync_api import sync_playwright
    headless_env = os.getenv("HEADLESS", "1").strip()
    headless = headless_env != "0"
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=headless)
        page = browser.new_page()
        page.set_default_timeout(120000)
        page.goto(LV_URL, wait_until="domcontentloaded")
        try:
            page.wait_for_load_state("networkidle", timeout=20000)
        except Exception:
            pass
        page.wait_for_timeout(3000)

        def dump_frame(frame, tag: str):
            tables = frame.locator("table")
            nt = tables.count()
            for i in range(nt):
                t = tables.nth(i)
                try:
                    t.scroll_into_view_if_needed(timeout=2000)
                except Exception:
                    pass
                headers, rows = _tabla_a_matriz(t)
                _imprimir_tabla(headers, rows, f"{tag} · TABLA #{i}")

        dump_frame(page, "MAIN")
        for idx, fr in enumerate(page.frames):
            if fr == page.main_frame:
                continue
            try:
                url = fr.url
            except Exception:
                url = "(sin url)"
            print(f"\n[DBG] ===== IFRAME #{idx} :: {url} =====")
            dump_frame(fr, f"IFRAME#{idx}")
        browser.close()

def _nearest_title_js():
    return r"""
const tables = Array.from(document.querySelectorAll('table'));
function getNearestTitle(el) {
  let cont = el.closest(".card, .panel, .box, section, .widget, .portlet, .modulo, .module, .contenedor, .container") || el.parentElement;
  function getTitleFrom(node) {
    if (!node) return "";
    const pick = node.querySelectorAll("h1,h2,h3,h4,h5,.title,.titulo,.header,.card-header,.panel-heading,.box-title,.widget-title,.modulo-titulo, .section-title, .section-header");
    let text = "";
    for (const t of pick) {
      const s = (t.innerText || "").trim();
      if (s && s.length > 0) text += " " + s;
    }
    if (text.trim().length > 0) return text.trim();
    return "";
  }
  let title = getTitleFrom(cont);
  if (!title) {
    let sib = el.previousElementSibling;
    while (sib) {
      const s = (sib.innerText || "").trim();
      if (s && s.length > 0) { title = s; break; }
      sib = sib.previousElementSibling;
    }
  }
  if (!title) {
    let sib2 = cont ? cont.previousElementSibling : null;
    while (sib2) {
      const s = (sib2.innerText || "").trim();
      if (s && s.length > 0) { title = s; break; }
      sib2 = sib2.previousElementSibling;
    }
  }
  return (title || "").trim();
}

return tables.map((t, i) => {
  return {
    idx: i,
    title: getNearestTitle(t),
    outerHTML: t.outerHTML
  };
});
"""

def get_todas_las_tablas(timeout: int = 45,
                         headless: bool = True,
                         debug: bool = True) -> list[dict]:
    opts = webdriver.ChromeOptions()
    if headless:
        opts.add_argument("--headless=new")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--disable-dev-shm-usage")
    opts.add_argument("--window-size=1920,1080")
    opts.add_argument("--log-level=3")
    opts.add_experimental_option("excludeSwitches", ["enable-logging","enable-automation"])
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=opts) 
    text = []
    try:
        wait = WebDriverWait(driver, timeout)
        driver.get(URL)
        wait.until(EC.presence_of_element_located((By.TAG_NAME, "body")))
        for y in (300, 900, 1500, 2200, 0):
            driver.execute_script(f"window.scrollTo({{top:{y}}});")
            time.sleep(0.6)
        tables_info = driver.execute_script(_nearest_title_js())
        if debug:
            for t in tables_info:
                text.append(t)
    finally:
        driver.quit()
    return text

def tablas_a_dataframes() -> dict[str, pd.DataFrame]:
    from playwright.sync_api import sync_playwright
    headless_env = os.getenv("HEADLESS", "1").strip()
    headless = headless_env != "0"
    creados = {}
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=headless)
        page = browser.new_page()
        page.set_default_timeout(120000)
        page.goto(LV_URL, wait_until="domcontentloaded")
        try:
            page.wait_for_load_state("networkidle", timeout=20000)
        except Exception:
            pass
        page.wait_for_timeout(3000)
        tables = page.locator("table")
        nt = tables.count()
        for i in range(1, nt):
            t = tables.nth(i)
            headers, rows = _tabla_a_matriz(t)
            if not headers or not rows:
                continue
            nombre_base = headers[0]
            nombre_norm = unicodedata.normalize("NFKD", nombre_base)
            nombre_norm = "".join(c for c in nombre_norm if not unicodedata.combining(c))
            nombre_norm = nombre_norm.replace(" ", "_")
            varname = f"df_{nombre_norm}"
            df = pd.DataFrame(rows, columns=headers)
            globals()[varname] = df
            creados[varname] = df
        browser.close()
    return creados

def acciones_df() -> pd.DataFrame:
    tablas = get_todas_las_tablas(headless=True, debug=True)
    title_text = tablas[2]['title']
    lineas = [l for l in title_text.strip().split("\n") if l.strip()]
    _ = lineas[0]
    filas = [l.split("\t") for l in lineas[1:]]
    df_Acciones = pd.DataFrame(filas, columns=["Acción", "Precio", "Var.%"])
    def to_float_ch(s):
        s = s.strip()
        s = s.replace(".", "")
        s = s.replace(",", ".")
        s = s.replace("%", "")
        s = s.replace("+", "")
        return float(s)

    df_Acciones["Precio"] = df_Acciones["Precio"].apply(to_float_ch)
    df_Acciones["Var.%"] = df_Acciones["Var.%"].apply(to_float_ch)

    tickers = [
        "AGUAS-A","ANDINA-B","BCI","BSANTANDER","CAP","CCU","CENCOSUD","CHILE",
        "CMPC","COLBUN","CONCHATORO","COPEC","ECL","ENELAM","ENELCHILE","ENELGXCH",
        "ENTEL","FALABELLA","FORUS","HITES","ILC","ITAUCL","LTM","MALLPLAZA",
        "PARAUCO","RIPLEY","SALFACORP","SECURITY","SMU","SONDA","SQM-B","TRICOT","VAPORES"
    ]
    df_Acciones = df_Acciones[df_Acciones["Acción"].isin(tickers)]
    df_Acciones = df_Acciones.set_index("Acción").reindex(tickers).reset_index()
    return df_Acciones

def fusionar_dataframes() -> list[tuple[str, pd.DataFrame]]:
    lista = []
    try:
        df_a = acciones_df()
        lista.append(("df_Acciones", df_a))
    except Exception as e:
        print(f"[WARN] acciones_df() falló: {e}")
    try:
        tablas_df = tablas_a_dataframes()
        for name, df in sorted(tablas_df.items()):
            lista.append((name, df))
    except Exception as e:
        print(f"[WARN] tablas_a_dataframes() falló: {e}")
    return lista

if __name__ == "__main__":
    start_time = time.time()
    print("Ejecutando en modo automático (sin input)…")
    dataframes = fusionar_dataframes()
    if not dataframes:
        print("No se generaron DataFrames.")
    else:
        for name, df in dataframes:
            print(f"\n=== {name} ({df.shape[0]} filas x {df.shape[1]} cols) ===")
            try:
                print(df)
            except Exception:
                print(df.head())
    end_time = time.time()
    print("Inicio:", datetime.datetime.fromtimestamp(start_time))
    print("Final:", datetime.datetime.fromtimestamp(end_time))
    print("Tiempo total:", end_time - start_time, "segundos")